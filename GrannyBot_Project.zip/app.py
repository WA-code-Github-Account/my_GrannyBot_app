
import streamlit as st
import random
from gtts import gTTS
import os

st.set_page_config(page_title="GrannyBot - Pyari Dadi", layout="centered")
st.title("GrannyBot - Pyari Dadi Ki Awaaz Mein")

# --- Sample Data ---
totkay = [
    "Sardard mein arq-e-gulab se maatha sekhna mufeed hai.",
    "Zaytun ka tail chehre ki jild ke liye behtareen hai.",
    "Haldi aur doodh ka mix thand ke liye acha hai.",
    "Adrak ka kehwa zukaam mein bohat faida deta hai.",
    "Neem ke patton ka lep daano ke liye behtareen hai.",
    "Multani mitti chehre ke liye natural cleanser hai.",
    "Kalonji har marz ka ilaj hai siwae maut ke.",
    "Raat ko doodh mein badam bhigo kar khana dimagh ke liye acha hai.",
    "Munh se badbu door karne ke liye sauf ka istemal karein.",
    "Gharelu ubtan chehre ko chamakdaar banata hai."
]

kahaniyan = [
    "Ek baar ka zikr hai, ek chor ne budhi aurat ki madad ki aur badle mein uska dil badal gaya.",
    "Ek choti si chiriya ne apni mehnat se sabko hairan kar diya.",
    "Ek waqt tha jab aik gareeb ne apna aakhri paisa kisi bhookay ko de diya.",
    "Ek mochi ne apne kaam se izzat kamai aur logon ka dil jeeta.",
    "Ek larki har roz ek budhi aurat ko khana deti thi aur usay dua milti thi.",
    "Ek sher aur chuhe ki dosti ne sabko hairan kar diya.",
    "Ek nanhi si bachi ne sabak diya ke ahankaar kabhi acha nahi hota.",
    "Ek buzurg ne bachon ko sabr ka matlab samjhaya.",
    "Ek andha shakhs roshni ka raasta dikhata tha.",
    "Ek waqt tha jab ek choti se madad ne kisi ki zindagi badal di."
]

nasihatain = [
    "Beta, waqt ki qadr karo, ye dobara nahi milta.",
    "Sada sach bolna, jhoot se hamesha doori ikhtiyar karo.",
    "Namaz ki pabandi zindagi mein barkat laati hai.",
    "Apno se pyar se baat karo, zindagi choti si hai.",
    "Hamesha shukar guzar raho, jitna hai usi mein khushi dhoondo.",
    "Parhne ki aadat daalo, ilm kabhi zaya nahi jaata.",
    "Buron ka jawab achai se do, Allah sab dekhta hai.",
    "Kisi ka dil mat dukhao, dil Allah ka ghar hota hai.",
    "Buzurgon ki izzat karo, dua milegi.",
    "Rozana kuch naya seekhne ki koshish karo."
]

duaein = [
    "Allah tumhe har burai se mehfooz rakhe.",
    "Khush raho mere bache, har mod pe kamiyabi mile.",
    "Tumhara naseeb chamak uthe, Ameen.",
    "Jahan bhi jao, log tumse pyar karein.",
    "Tumhara dil kabhi udaas na ho.",
    "Har mushkil asaan ho jaye, Ameen.",
    "Allah tumhe sehat aur lambi zindagi de.",
    "Tumhe har manzil asaani se mil jaye.",
    "Tumhara har din khushi wala ho.",
    "Dadi ki duaon mein tum hamesha shaamil ho."
]

def get_response(user_input):
    text = user_input.lower()
    if "totka" in text:
        return random.choice(totkay)
    elif "kahani" in text:
        return random.choice(kahaniyan)
    elif "nasihat" in text:
        return random.choice(nasihatain)
    elif "dua" in text:
        return random.choice(duaein)
    else:
        return "Beta, main samajh nahi paayi. Totka, kahani, nasihat ya dua poochho."

def speak_text(text):
    tts = gTTS(text=text, lang='ur')
    filename = "granny_voice.mp3"
    tts.save(filename)
    audio_file = open(filename, 'rb')
    audio_bytes = audio_file.read()
    st.audio(audio_bytes, format='audio/mp3')
    audio_file.close()
    os.remove(filename)

user_input = st.text_input("Apna paighaam likhein (e.g., dadi koi kahani sunao):")
if st.button("Sunayein!") and user_input:
    response = get_response(user_input)
    st.write("**Dadi:**", response)
    speak_text(response)
